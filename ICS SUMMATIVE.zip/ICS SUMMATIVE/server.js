if (process.env.NODE_ENV !== "production") {
    require("dotenv").config();
}

// import installed node.js packages
const express = require("express");
const path = require("path");
const bcrypt = require("bcrypt");
const passport = require("passport");
const flash = require("express-flash");
const session = require("express-session");
const methodOverride = require("method-override");
const sqlite3 = require("sqlite3").verbose();

const initializePassport = require("./passport-config");

// app setup
const app = express();
const PORT = process.env.PORT || 3000;

// SQLite database
const db = new sqlite3.Database("users.db", (err) => {
    if (err) {
        return console.error("Failed to connect to database:", err.message);
    }
    console.log("Connected to SQLite database.");
});

// helper FNs
function getUserByEmail(email) {
    return new Promise((resolve, reject) => {
        db.get("SELECT * FROM users WHERE email = ?", [email], (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

function getUserById(id) {
    return new Promise((resolve, reject) => {
        db.get("SELECT * FROM users WHERE id = ?", [id], (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
}

// initialize passport
initializePassport(passport, getUserByEmail, getUserById);

// app uses
app.use(express.urlencoded({ extended: false }));
app.use(express.static('public'));
app.use(flash());
app.use(session({
    secret: process.env.SECRET_KEY,
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(methodOverride("_method"));

// routes

// home page
app.get("/", checkAuthenticated, (req, res) => {
    res.render("index.ejs", { name: req.user.name });
});

// page 1
app.get("/page1", checkAuthenticated, (req, res) => {
    res.render("page1.ejs");
})

// page 2
app.get("/page2", checkAuthenticated, (req, res) => {
    res.render("page2.ejs");
})

// page 3
app.get("/page3", checkAuthenticated, (req, res) => {
    res.render("page3.ejs");
})

// page 4
app.get("/page4", checkAuthenticated, (req, res) => {
    res.render("page4.ejs");
})

// page 5
app.get("/page5", checkAuthenticated, (req, res) => {
    res.render("page5.ejs");
})

// page 6
app.get("/page6", checkAuthenticated, (req, res) => {
    res.render("page6.ejs");
})

// page 7
app.get("/page7", checkAuthenticated, (req, res) => {
    res.render("page7.ejs");
})

// page 8
app.get("/page8", checkAuthenticated, (req, res) => {
    res.render("page8.ejs");
})

// page 9
app.get("/page9", checkAuthenticated, (req, res) => {
    res.render("page9.ejs");
})

// login
app.get("/login", checkNotAuthenticated, (req, res) => {
    res.render("login.ejs");
});
app.post("/login", checkNotAuthenticated, passport.authenticate("local", {
    successRedirect: "/",
    failureRedirect: "/login",
    failureFlash: true
}));

// register
app.get("/register", checkNotAuthenticated, (req, res) => {
    res.render("register.ejs");
});

app.post("/register", checkNotAuthenticated, async (req, res) => {
    const { name, email, password } = req.body;

    db.get("SELECT * FROM users WHERE email = ?", [email], async (err, row) => {
        if (err) {
            console.error(err);
            return res.redirect("/register");
        }

        if (row) {
            req.flash("error", "Email already registered.");
            return res.redirect("/register");
        }

        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            db.run(
                "INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)",
                [Date.now().toString(), name, email, hashedPassword],
                (err) => {
                    if (err) {
                        console.error(err);
                        return res.redirect("/register");
                    }
                    res.redirect("/login");
                }
            );
        } catch (e) {
            console.error(e);
            res.redirect("/register");
        }
    });
});

// logout
app.delete("/logout", (req, res) => {
    req.logout(req.user, err => {
        if (err) return next(err);
        res.redirect("/login");
    });
});

// authentication
function checkAuthenticated(req, res, next) {
    if (req.isAuthenticated()) return next();
    res.redirect("/login");
}

function checkNotAuthenticated(req, res, next) {
    if (req.isAuthenticated()) return res.redirect("/");
    next();
}

// start server

app.listen(3000);